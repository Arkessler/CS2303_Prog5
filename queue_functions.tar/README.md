This is a working implementation of round robin queue.
All code in this part originated from Bob Kiniki, modified to use classes.

Run format: ./prog3 numProc timeSlice < prog3.dat > prog3.out

