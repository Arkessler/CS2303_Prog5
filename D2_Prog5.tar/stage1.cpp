#ifndef STAGE1_CPP
#define STAGE1_CPP

void stage1 ()
{
	//First need to read in all the robots 
	//Then begin by adding in the first robot at time 0
	//While loop, RobotsNotInSim is not empty
		//Increment Robots
	//While loop, Robots in Sim not empty
		//increment Robots
}

void incrementRobots()
{
	//For loop, every Robot in RobotsInSim
		//Move one step towards destination (incrementRobot?)
	//Increment simTime
}
#endif
